<?php

// Configuration
$version = '0.4 beta';
$table = 'ipvrf';
$database = 'mpls';
$user = '*user*';
$pass = '*pass*';

?>
