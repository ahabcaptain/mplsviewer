<?php

// Configuration
$version = '0.5 alpha';
$table = 'ipvrf';
$database = 'nfs_mpls';
$user = '*user*';
$pass = '*pass*';

?>
