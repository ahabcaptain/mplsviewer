<?php
// Includes
include 'includes/config.php';
include 'includes/php-functions.php';

// Mark the start time
$start = timer_start();

// Html start

echo '<html><head>';
echo '<link rel="stylesheet" type="text/css" href="includes/main.css">';
echo '<title>Mplsviewer '.$conf->version.'</title>';
echo '</head>';
echo "<body style='font-family: monospace; height: 100%' GCOLOR='#FFFFFF'>";
top_box('');
echo "<TABLE WIDTH='100%' BORDER='1' ALIGN='center' CELLPADDING='5' CELLSPACING='0'>";
echo "<TR>";
echo "<TD style='padding-left:10px;' valign='top'><br>";
echo 'Show<hr align="left" width="120">';
echo '<a class="m_blue" href="vrf.php">vrf view</a><br>';
echo '<a class="m_blue" href="device.php">device view</a><br>';
echo '<br>';
echo 'Other<hr align="left" width="120">';
echo '<a class="m_blue" href="parse.php">Parse configs</a><br>';

// Html end
echo "<br></TD></TR></table>";

// Dump time passed since start
timer_end($start);

echo "<br>";
echo $conf->copyright;
echo '</body></html>';
?>
