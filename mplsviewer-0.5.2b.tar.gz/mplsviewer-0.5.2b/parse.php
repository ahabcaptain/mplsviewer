<?php

// Includes
include 'includes/config.php';
include 'includes/parse-functions.php';
include 'includes/php-functions.php';
include 'includes/mysql-functions.php';

// Mark the start time
$start = timer_start();

// Connect to the database
dbconn("localhost", $conf->database, $conf->usr, $conf->pass);

// Html start
echo '<html><head><link rel="stylesheet" type="text/css" href="includes/main.css"></head>';
echo "<body style='font-family: monospace; height: 100%' GCOLOR='#FFFFFF'>";
top_box("Importing to db: $conf->database, table: $conf->table");
echo "<TABLE WIDTH='100%' BORDER='1' ALIGN='center' CELLPADDING='5' CELLSPACING='0'>";
echo "<TR>";
echo "<TD valign='top'><br>";

// Count rows and flush the main table and output
$count = countsql();
echo "<b>Flusing ".$count." records.</b><hr><br>";
dbclean($conf->table);

// Parse and re-enter the data into main table
echo "Importing mpls enabled devices: <br>";
$count=0;
foreach(check_mpls($conf->rancid) as $devname) {
$count = parseconfig(trim($devname), $count);
echo "$devname<br>";
}
echo "Lines parsed: $count<br>";

// Recount the main table and output
$count = countsql();
echo "<b><br><hr>Imported ".$count." records.<br>";

// Html end
echo "<br></TD></TR></table>";

// Dump time passed since start
timer_end($start);

echo '<br>';
echo $conf->copyright;
echo '</body></html>';

?>
