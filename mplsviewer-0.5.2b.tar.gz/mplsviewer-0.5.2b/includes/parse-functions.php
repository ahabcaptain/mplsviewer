<?php
// Parse config from file
function parseconfig($fileName, $count) {

global $conf;

$vrftype = ""; $done = "0";
foreach($conf->rancid as $dirname) {
if (strpos($fileName, $dirname) !== false) {$device = str_replace($dirname, "", $fileName);}
}
    if(file_exists($fileName))
    {
        $file = fopen($fileName,'r');
        while(!feof($file))
        {
                $name = fgets($file);
                if(substr($name,0,10) == 'interface ') { $done = "1"; }
                if(substr($name,0,7) == 'router ') { $done = "2"; }
                if($done<"1")
                { // stop running after ^interface is hit.
                        $array = explode(' ', $name);
                        if(substr($name,0,7) == 'ip vrf ')
                        {
                                $vrf = trim($array[2]);
                                $vrftype = 'ipvrf';
                                $vrfhit = "1";
                        } elseif (substr($name,0,15) == 'vrf definition ')
                        {
                                $vrf = trim($array[2]);
                                $vrftype = 'definition';
                                $vrfhit = "1";
                        } elseif (substr($name,0,16) == ' address-family ')
                        {
                                if(trim($array[2])=='ipv4') {
                                        $address_family = 'v4';
                                } else {
                                        $address_family = 'v6';
                                }
                        } else
                        {
                        // set different lookup based on vrf type
                        if($vrftype=="ipvrf")
                        {
                                if(substr($name,0,13) == ' description ') {
                                        if($vrfhit=="1") {
                                                $sliced = array_slice($array, 2);
                                                $imploded = implode(' ',$sliced);
                                                makesql($device, $vrf, '', trim($imploded), 'desc', $vrftype, 'v4');
                                                $vrfhit = "0";
                                                }
                                } else {
                                        if(substr($name,0,21) == ' route-target export ') { makesql($device, $vrf, '', trim($array[3]), 'export', $vrftype, 'v4');
                                } else {
                                        if(substr($name,0,21) == ' route-target import ') { makesql($device, $vrf, '', trim($array[3]), 'import', $vrftype, 'v4');
                                } else {
                                        if(substr($name,0,12) == ' export map ') { makesql($device, $vrf, '', trim($array[3]), 'exportmap', $vrftype, 'v4');
                                } else {
                                        if(substr($name,0,12) == ' import map ') { makesql($device, $vrf, '', trim($array[3]), 'importmap', $vrftype, 'v4');
                                } else {
                                        $vrfhit = "0";
                                }}}}}
                        } elseif($vrftype=="definition")
                        {
                                if(substr($name,0,13) == ' description ') {
                                        if($vrfhit=="1")
                                        {
                                                $sliced = array_slice($array, 2);
                                                $imploded = implode(' ',$sliced);
                                                makesql($device, $vrf, '', trim($imploded), 'desc', $vrftype, $address_family);
                                                $vrfhit = "0";
                                        }
                                } else {
                                        if(substr($name,0,21) == ' route-target export ') { makesql($device, $vrf, '', trim($array[3]), 'export', $vrftype, 'v4 v6');
                                } else {
                                        if(substr($name,0,21) == ' route-target import ') { makesql($device, $vrf, '', trim($array[3]), 'import', $vrftype, 'v4 v6');
                                } else {
                                        if(substr($name,0,22) == '  route-target export ') { makesql($device, $vrf, '', trim($array[4]), 'export', $vrftype, $address_family);
                                } else {
                                        if(substr($name,0,22) == '  route-target import ') { makesql($device, $vrf, '', trim($array[4]), 'import', $vrftype, $address_family);
                                } else {
                                        if(substr($name,0,13) == '  export map ') { makesql($device, $vrf, '', trim($array[4]), 'exportmap', $vrftype, $address_family);
                                } else {
                                        if(substr($name,0,13) == '  import map ') { makesql($device, $vrf, '', trim($array[4]), 'importmap', $vrftype, $address_family);
                                } else {
                                        $vrfhit = "0";
                                }}}}}}}
                        }
                        }
                }
                if($done=="1")
		{
                  $array = explode(' ', $name);
                  if ($array[0]=='interface') {
                        $interface = trim($array[1]);
                  } else {
	                if(substr($name,0,8) == ' ip vrf ') {  
				if($array[5])
					{ makesql($device, trim($array[4]), trim($array[6]), $interface, 'interface', 'hd', 'any'); }
				else
					{ makesql($device, trim($array[4]), '', $interface, 'interface', 'vrf', 'any'); }
                  } else {
                        if(substr($name,0,5) == ' vrf ') {
                                if($array[4])
                                        { makesql($device, trim($array[3]), trim($array[5]), $interface, 'interface', 'hd', 'any'); }
                                else
                                        { makesql($device, trim($array[3]), '', $interface, 'interface', 'vrf', 'any'); }
                  }}}
               }
	$count++;
        }
    } else { echo "File not found: $fileName";  }

fclose($file);
return $count;
}

?>
