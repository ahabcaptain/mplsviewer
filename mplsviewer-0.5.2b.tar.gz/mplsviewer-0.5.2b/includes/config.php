<?php

// Configuration
$conf->database = 'mpls';
$conf->table = 'mpls';
$conf->usr = '*user*';
$conf->pass = '*pass*';
$conf->rancid = array('/var/rancid/var/hys/configs/','/var/rancid/var/client/configs/', '/var/rancid/var/skyrr/configs/');

// Version and copyright
$conf->version = '0.5.2b';
$conf->copyright = '<small>Copyright &copy; 2012 by Aki Hermann Barkarson, All rights reserved.</small>';

?>
