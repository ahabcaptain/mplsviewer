<?php

function top_box($string) {
global $conf;
echo "<div align='center'>";
echo "<TABLE width='100%' CELLPADDING='0' cellspacing='0' width=550px class='generaltext' style='border-style:solid; border-width:1px; border-color: gray; margin-top:10px;'>";
echo "<tr>";
echo "<td style='text-align: left; background:#300060; color: #DDDDDD; padding:5px' valign='top'>";
echo "<B><FONT FACE='Verdana, Arial, Helvetica, sans-serif' SIZE='2'>";
if($string!='') { echo "<a class='m_white' href='./'>Home</a> -> $string"; }
else { echo "Mplsviewer $conf->version"; }
echo "</FONT></B>";
echo "</td>";
echo "</tr>";
echo "</TABLE>";
echo "</div>";
}

function timer_start()  {
$start=microtime();
$start=explode(" ",$start);
$start=$start[1]+$start[0];
return($start);
}

function timer_end($var)  {
$end=microtime();
$end=explode(" ",$end);
$end=$end[1]+$end[0];

echo "<br>";
printf("Completed in  : %f seconds. ",$end-$var);
echo "<br>";
echo "Using memory : ", memory_get_usage(1), " bytes.";
echo "<br>";
}

// I tried multiple ways of php opening the files and perl.. but as far as speed goes.. this grep is the bomb!
// But I'd love to know if there is a faster way to get this info.. ahab.captain@gmail.com if you know how.. :-)
function check_mpls($rancid) {
        foreach($rancid as $entry) {
                $output = shell_exec("grep -l '^ mpls ip\|^ tag-switching ip' ".$entry."* | grep -v .new$");
                $lines[] = preg_split ('/$\R?^/m', $output);
        }
return(flat($lines));
}

// Flatten arrays, recursively :-) very neat
function flat($array) {
  if (!is_array($array)) {
    return FALSE;
  }
  $result = array();
  foreach ($array as $key => $value) {
    if (is_array($value)) {
      $result = array_merge($result, flat($value));
    }
    else {
      if($value) { $result[$key] = $value; }
    }
  }
  return $result;
}


// Make array key unique in php array (like 'select distinct' in mysql)
function super_unique($array,$key)
{
   $temp_array = array();
   foreach ($array as &$v) {
       if (!isset($temp_array[$v[$key]]))
       $temp_array[$v[$key]] =& $v;
   }
   $array = array_values($temp_array);
   return $array;
}

?>
