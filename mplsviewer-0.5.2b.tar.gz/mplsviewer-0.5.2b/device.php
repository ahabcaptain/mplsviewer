<?php

// Global includes
include 'includes/header.php';
include 'includes/config.php';
include 'includes/mysql-functions.php';
include 'includes/php-functions.php';

// Mysql fucntions:
//
// $data = get_data($table);
// $vrf = get_data_vrf($table, 'ytranet');
// $single_device = get_data_device($table, 'hyscore01');
// $value = get_data_vrfvalue($table, $data, 'hyscore01', 'ytranet', 'rd');
//
// Gets lists of strings into an array, no data:
//
// $devices = get_devices($table);
// $RDs = get_RDs($table);
// $vrfs = get_vrfs($table);

// PHP functions:
//
// get_data_vrfvalue($table, Array $array, $device, $vrf, $searchkey) 
// super_unique($array,$key)
//

// #########################
// # Main code area starts #
// #########################

dbconn("localhost", $conf->database, $conf->usr, $conf->pass);

$selected='';

if(isset($_POST['sort'])){ $sort = $_POST['sort']; } else { if($_GET['sort']){ $sort = $_GET['sort']; }}
if(isset($_GET['select'])) { $selected = $_GET['select']; }
if(isset($_POST['select'])) { $selected = $_POST['select']; }

echo "<body style='font-family: monospace; height: 100%' GCOLOR='#FFFFFF'>";

$header = 'Device';
if($selected) { $header .= " : ".$selected; }
top_box($header);

echo "<form onsubmit='return show(this)' id='form1' name='form1' method='post' action='' accept-charset='UTF-8'>";
echo "<TABLE WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='1' BGCOLOR='white'>";
echo "<TR>";
echo "<TD valign='top'>";
echo "<TABLE WIDTH='100%' BORDER='1' ALIGN='center' CELLPADDING='5' CELLSPACING='0'>";
echo "<TR>";
echo "<TD valign='top' WIDTH='135px' ROWSPAN='2' ALIGN='left' BGCOLOR='#FFFFFF'>";
echo "<b><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'>Type to search:</FONT></b>";
echo "<p style='margin-top:0px;'>";
echo "<SELECT style='float:left; width:180px' onclick='formSubmit()' NAME='select' SIZE='40'>";
echo "<option value='0'></option>";

$devices = get_devices($conf->table);
$data = get_data($conf->table);


foreach (super_unique($devices,'device') as $entry)
{
	echo "<OPTION VALUE=".$entry['device']." ";
	if ($selected==$entry['device']) {echo "selected";} 
	echo ">".$entry['device']." ";
	echo "</OPTION>";
}
unset($devices, $entry);

echo "</SELECT>";
echo "<input name='formtxt' onkeyup='search(this.form)' style='float:left; margin:1px 0px 0px -179px; padding-left:3px; width:158px; border:0px; background:#eee'>";
echo "</p>";
echo "<BR />";
echo "<INPUT TYPE='hidden' NAME='Submit' VALUE='View' /> <BR />";
echo "<INPUT TYPE='hidden' NAME='sort' VALUE='' /> ";
echo "</TD>";
echo "<TD ALIGN='left' BGCOLOR='#FFFFFF' style='padding-right:12px;'>";
echo "<div style='min-height:700px;'>";

if($selected)
{
	$devicedata = get_data_device($conf->table, $selected);
	echo "<b><FONT FACE='Arial, Helvetica, sans-serif' SIZE='2'>Sort exporters/importers by:</FONT></b>";
	echo "<input type='button' onclick='formSubmit(\"vrf\")' value='vrf'/>";
	echo "<input type='button' onclick='formSubmit(\"device\")' value='device'/>";
	echo "<table BGCOLOR='#F0F0F0' style='height: 100%;' width='100%' cellspacing='0' cellpadding='0' border='1'>";
        echo "<tr>";
	echo "<th BGCOLOR='#A0A0A0'>Device</th>";
	echo "<th BGCOLOR='#A0A0A0' style='width:370px'>Imported Communities</th>";
	echo "<th BGCOLOR='#A0A0A0' style='width:370px'>Exported Communities</th>";
	echo "</tr>";
	foreach (super_unique($devicedata,'name') as $entry)
	{
		echo "<tr>";
		echo "<td valign='top' BGCOLOR='#909090' style='width: 95px; border-bottom: solid black 2px;'><br><center><b>";
                echo "<a class='m_white' href='vrf.php?select=".$entry['name'];
                if ($sort!='') { echo "&sort=".$sort; }
                echo "'>";
		echo $entry['name'];
		echo "</a>";
		echo "</b></center></td>";

// Import Communities start

		echo "<td style='vertical-align:top;'><center>";
		echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
		echo "<th style='background-color: #D0D0D0; padding-left: 5px; border-bottom: solid black 1px;'><b>Community</b></th>";
		echo "<th style='background-color: #D0D0D0; padding-left: 5px; border-left: solid #909090 1px;'><b>Exporters</b></th>";
		echo "</tr>";
		foreach ($devicedata as $subentry)
		{
			if($subentry['name']==$entry['name'] && $subentry['import']!='')
			{
				echo "<tr><td style='padding-top: 3px; vertical-align:top; background-color: #F0F0F0; width: 100px; border-bottom: solid black 1px'><center><b>";
				echo $subentry['import'];
                                echo "</b><br><small>".$subentry['family']."</small></center></td>";
				echo "<td style='background-color: #F0F0F0;'>";
				$result = '' ;
				if($sort!='device')
				{
					// sort by VRF
					$i = '0';
					foreach ($data as $dataentry)
					{
						if ($subentry['import']==$dataentry['export'])
						{
						 if ($dataentry['device']==$selected && $dataentry['name']==$entry['name'])
						{
						} else
						 {
						 $result[] =  array('name' => $dataentry['name'], 'device' => $dataentry['device'], 'family' => $dataentry['family']);
						 asort($result);
						 $i++;
						 }
						}
					}
					if ($i=='0')
					{
						echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
						echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px; border-left: solid black 1px; padding-left: 5px;'> vrf</td>";
						echo "<td style='width: 155px; background-color: #D0D0D0; border-bottom: solid black 1px; '>af &nbsp;&nbsp;&nbsp;device</td>";
						echo "</tr>";
						echo "<tr><td style='border-bottom: solid black 1px'><center>";
						echo "<i><b><font color='#FF0000'>unused</color></b></i>";
						echo "</center></td>";
						echo "<td style='border-bottom: solid black 1px'><center>";
						echo "<i><b><font color='#F0F0F0'>unused</color></b></i>";
						echo "</center></td>";
						echo "</tr></table>";
					} else {
						echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
						echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px; border-left: solid black 1px; padding-left: 5px;'> vrf</td>";
						echo "<td style='width: 155px; background-color: #D0D0D0; border-bottom: solid black 1px; '>af &nbsp;&nbsp;&nbsp;device</td>";
						echo "</tr>";
					foreach (super_unique($result,'name') as $row)
					{
						echo "<tr><td style='padding-left: 4px; border-bottom: solid black 1px'>";
						echo "<b>";
						echo "<a class='m_blue' href='vrf.php?select=".$row['name'];
						if ($sort!='') { echo "&sort=".$sort; }
						echo "'> ";
						echo $row['name'];
						echo "</a>";
						echo "</b>";
						echo "</td>";
						echo "<td style='border-bottom: solid black 1px'>";
						echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
						foreach ($result as $subrow)
						{
							if($subentry['family']=="v4 v6")
							{
							
								if($subrow['name']==$row['name'] )
								{
									echo "<tr><td style='width:50px;'>";
									echo $subrow['family'];
									echo "</td>";
									echo "<td>";
							                echo "<a class='m_blue' href='vrf.php?select=".$subrow['device'];
							                if ($sort!='') { echo "&sort=".$sort; }
							                echo "'>";
									echo $subrow['device'];
									echo "</a></td></tr>";
								}
							} else {
							        if($subrow['name']==$row['name'] && $subrow['family']==$subentry['family'])
                                                                {
                                                                        echo "<tr><td style='width:50px;'>";
                                                                        echo $subrow['family'];
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo "<a class='m_blue' href='device.php?select=".$subrow['device'];
                                                                        if ($sort!='') { echo "&sort=".$sort; }
                                                                        echo "'>";
                                                                        echo $subrow['device'];
                                                                        echo "</a></td></tr>";
                                                                }
							}
						}
						echo "</table>";
					}
						echo "</td></tr></table>";
					}
				} else {
					// Sort by Devices
					$i = '0';
				        foreach ($data as $dataentry)
                                        {
                                                if ($subentry['import']==$dataentry['export'])
                                                {
                                                 if ($dataentry['device']==$selected && $dataentry['name']==$entry['name'])
                                                {
                                                } else
                                                 {
                                                 $result[] =  array('device' => $dataentry['device'], 'name' => $dataentry['name'], 'family' => $dataentry['family']);
                                                 asort($result);
						 $i++;
                                                 }
                                                }
                                        }
					if ($i=='0')
					{
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 155px; background-color: #D0D0D0; padding-left:5px; border-bottom: solid black 1px; border-left: solid black 1px; '>device</td>";
                                                echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px; padding-left: 5px;'>af vrf</td>";
                                                echo "</tr>";
                                                echo "<tr><td style='border-bottom: solid black 1px'><center>";
                                                echo "<i><b><font color='#FF0000'>unused</color></b></i>";
                                                echo "</center></td>";
                                                echo "<td style='border-bottom: solid black 1px'><center>";
                                                echo "<i><b><font color='#F0F0F0'>unused</color></b></i>";
                                                echo "</center></td>";
                                                echo "</tr></table>";
                                        } else {
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 110px; background-color: #D0D0D0; padding-left:5px; border-bottom: solid black 1px; border-left: solid black 1px;'>device</td>";
                                                echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px;'>af &nbsp;&nbsp;&nbsp;vrf</td>";
                                                echo "</tr>";

                                        foreach (super_unique($result,'device') as $row)
                                        {
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 110px; padding-left: 4px; border-bottom: solid black 1px'>";
                                                echo "<b>";
                                                echo "<a class='m_blue' href='device.php?select=".$row['device'];
                                                if ($sort!='') { echo "&sort=".$sort; }
                                                echo "'>";
                                                echo $row['device'];
                                                echo "</a></b>";
                                                echo "</td>";
                                                echo "<td style='width: 175px; border-bottom: solid black 1px'>";
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
                                                foreach ($result as $subrow)
                                                {
                                                        if($subentry['family']=="v4 v6")
                                                        {

                                                                if($subrow['device']==$row['device'] )
                                                                {
                                                                        echo "<tr><td style='width:50px;'>";
                                                                        echo $subrow['family'];
                                                                        echo "</td>";
                                                                        echo "<td>";
							                echo "<a class='m_blue'  href='vrf.php?select=".$subrow['name'];
							                if ($sort!='') { echo "&sort=".$sort; }
							                echo "'>";
                                                                        echo $subrow['name'];
                                                                        echo "</a></td></tr>";
                                                                }
                                                        } else {
                                                                if($subrow['device']==$row['device'] && $subrow['family']==$subentry['family'])
                                                                {
                                                                        echo "<tr><td style='width:50px;'>";
                                                                        echo $subrow['family'];
                                                                        echo "</td>";
                                                                        echo "<td>";
							                echo "<a class='m_blue' href='vrf.php?select=".$subrow['name'];
							                if ($sort!='') { echo "&sort=".$sort; }
							                echo "'>";
                                                                        echo $subrow['name'];
                                                                        echo "</a></td></tr>";
                                                                }
                                                        }
                                                }
                                                echo "</table>";
                                                echo "</td></tr></table>";
                                        }
					}
				}
				reset($data);
				echo "</td>";
			} 
		} 
				echo "</tr></table>";
		echo "</center></td>";

// Export communities start

                echo "<td style='vertical-align:top;'><center>";
                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                echo "<th style='background-color: #D0D0D0; padding-left: 5px; border-bottom: solid black 1px;'><b>Community</b></th>";
                echo "<th style='background-color: #D0D0D0; padding-left: 5px; border-left: solid #909090 1px;'><b>Importers</b></th>";
                echo "</tr>";
                foreach ($devicedata as $subentry)
                {
                        if($subentry['name']==$entry['name'] && $subentry['export']!='')
                        {
                                echo "<tr><td style='padding-top: 3px; vertical-align:top; background-color: #F0F0F0; width: 100px; border-bottom: solid black 1px'><center><b>";
                                echo $subentry['export'];
                                echo "</b><br><small>".$subentry['family']."</small></center></td>";
                                echo "<td style='background-color: #F0F0F0;'>";
                                $result = '' ;
                                if($sort!='device')
                                {
                                        // sort by VRF
                                        $i = '0';
                                        foreach ($data as $dataentry)
                                        {
                                                if ($subentry['export']==$dataentry['import'])
                                                {
                                                 if ($dataentry['device']==$selected && $dataentry['name']==$entry['name'])
                                                {
                                                } else
                                                 {
                                                 $result[] =  array('name' => $dataentry['name'], 'device' => $dataentry['device'], 'family' => $dataentry['family']);
                                                 asort($result);
                                                 $i++;
                                                 }
                                                }
                                        }
                                        if ($i=='0')
                                        {
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px; border-left: solid black 1px; padding-left: 5px;'> vrf</td>";
                                                echo "<td style='width: 155px; background-color: #D0D0D0; border-bottom: solid black 1px; '>af &nbsp;&nbsp;&nbsp;device</td>";
                                                echo "</tr>";
                                                echo "<tr><td style='border-bottom: solid black 1px'><center>";
                                                echo "<i><b><font color='#FF0000'>unused</color></b></i>";
                                                echo "</center></td>";
                                                echo "<td style='border-bottom: solid black 1px'><center>";
                                                echo "<i><b><font color='#F0F0F0'>unused</color></b></i>";
                                                echo "</center></td>";
                                                echo "</tr></table>";
                                        } else {
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px; border-left: solid black 1px; padding-left: 5px;'> vrf</td>";
                                                echo "<td style='width: 155px; background-color: #D0D0D0; border-bottom: solid black 1px; '>af &nbsp;&nbsp;&nbsp;device</td>";
                                                echo "</tr>";
                                        foreach (super_unique($result,'name') as $row)
                                        {
                                                echo "<tr><td style='padding-left: 4px; border-bottom: solid black 1px'>";
                                                echo "<b>";
                                                echo "<a class='m_blue' href='vrf.php?select=".$row['name'];
                                                if ($sort!='') { echo "&sort=".$sort; }
                                                echo "'> ";
                                                echo $row['name'];
                                                echo "</a>";
                                                echo "</b>";
                                                echo "</td>";
                                                echo "<td style='border-bottom: solid black 1px'>";
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
                                                foreach ($result as $subrow)
                                                {
                                                        if($subentry['family']=="v4 v6")
                                                        {

                                                                if($subrow['name']==$row['name'] )
                                                                {
                                                                        echo "<tr><td style='width:50px;'>";
                                                                        echo $subrow['family'];
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo "<a class='m_blue' href='vrf.php?select=".$subrow['device'];
                                                                        if ($sort!='') { echo "&sort=".$sort; }
                                                                        echo "'>";
                                                                        echo $subrow['device'];
                                                                        echo "</a></td></tr>";
                                                                }
                                                        } else {
                                                                if($subrow['name']==$row['name'] && $subrow['family']==$subentry['family'])
                                                                {
                                                                        echo "<tr><td style='width:50px;'>";
                                                                        echo $subrow['family'];
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo "<a class='m_blue' href='device.php?select=".$subrow['device'];
                                                                        if ($sort!='') { echo "&sort=".$sort; }
                                                                        echo "'>";
                                                                        echo $subrow['device'];
                                                                        echo "</a></td></tr>";
                                                                }
                                                        }
                                                }
                                                echo "</table>";
                                        }
                                                echo "</td></tr></table>";
                                        }
                                } else {
                                        // Sort by Devices
                                        $i = '0';
                                        foreach ($data as $dataentry)
                                        {
                                                if ($subentry['export']==$dataentry['import'])
                                                {
                                                 if ($dataentry['device']==$selected && $dataentry['name']==$entry['name'])
                                                {
                                                } else
                                                 {
                                                 $result[] =  array('device' => $dataentry['device'], 'name' => $dataentry['name'], 'family' => $dataentry['family']);
                                                 asort($result);
                                                 $i++;
                                                 }
                                                }
                                        }
                                        if ($i=='0')
                                        {
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 155px; background-color: #D0D0D0; padding-left:5px; border-bottom: solid black 1px; border-left: solid black 1px; '>device</td>";
                                                echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px; padding-left: 5px;'>af vrf</td>";
                                                echo "</tr>";
                                                echo "<tr><td style='border-bottom: solid black 1px'><center>";
                                                echo "<i><b><font color='#FF0000'>unused</color></b></i>";
                                                echo "</center></td>";
                                                echo "<td style='border-bottom: solid black 1px'><center>";
                                                echo "<i><b><font color='#F0F0F0'>unused</color></b></i>";
                                                echo "</center></td>";
                                                echo "</tr></table>";
                                        } else {
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 110px; background-color: #D0D0D0; padding-left:5px; border-bottom: solid black 1px; border-left: solid black 1px;'>device</td>";
                                                echo "<td style='width: 175px; background-color: #D0D0D0; border-bottom: solid black 1px;'>af &nbsp;&nbsp;&nbsp;vrf</td>";
                                                echo "</tr>";

                                        foreach (super_unique($result,'device') as $row)
                                        {
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'><tr>";
                                                echo "<td style='width: 110px; padding-left: 4px; border-bottom: solid black 1px'>";
                                                echo "<b>";
                                                echo "<a class='m_blue' href='device.php?select=".$row['device'];
                                                if ($sort!='') { echo "&sort=".$sort; }
                                                echo "'>";
                                                echo $row['device'];
                                                echo "</a></b>";
                                                echo "</td>";
                                                echo "<td style='width: 175px; border-bottom: solid black 1px'>";
                                                echo "<table width='100%' cellspacing='0' cellpadding='0' border='0'>";
                                                foreach ($result as $subrow)
                                                {
                                                        if($subentry['family']=="v4 v6")
                                                        {

                                                                if($subrow['device']==$row['device'] )
                                                                {
                                                                        echo "<tr><td style='width:50px;'>";
                                                                        echo $subrow['family'];
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo "<a class='m_blue'  href='vrf.php?select=".$subrow['name'];
                                                                        if ($sort!='') { echo "&sort=".$sort; }
                                                                        echo "'>";
                                                                        echo $subrow['name'];
                                                                        echo "</a></td></tr>";
                                                                }
                                                        } else {
                                                                if($subrow['device']==$row['device'] && $subrow['family']==$subentry['family'])
                                                                {
                                                                        echo "<tr><td style='width:50px;'>";
                                                                        echo $subrow['family'];
                                                                        echo "</td>";
                                                                        echo "<td>";
                                                                        echo "<a class='m_blue' href='vrf.php?select=".$subrow['name'];
                                                                        if ($sort!='') { echo "&sort=".$sort; }
                                                                        echo "'>";
                                                                        echo $subrow['name'];
                                                                        echo "</a></td></tr>";
                                                                }
                                                        }
                                                }
                                                echo "</table>";
                                                echo "</td></tr></table>";
                                        }
                                        }
                                }
                                reset($data);
                                echo "</td>";
                        }
                }
                                echo "</tr></table>";
                echo "</center></td>";

//		echo "<td><center>";
//		 foreach ($vrfdata as $subentry)
//                {
//                        if($subentry['device']==$entry['device'] && $subentry['importmap']!='')
//                        {
//			echo "Importmap: ".$subentry['importmap'];
//			echo "<br>";
//			}
//                        if($subentry['device']==$entry['device'] && $subentry['exportmap']!='')
//                        {
//			echo "Exportmap: ".$subentry['exportmap'];
//			echo "<br>";
//			}
//		}
//
//		echo "</center></td>";
		echo "</tr>";
	}
	echo "</table>";
	
} else {
	echo "<b>Select from the list.</b><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
}

echo "</TD></TR></table>";

// Cleanup
unset($data, $vrf);

// Include footer
include 'includes/footer.php';

?>
