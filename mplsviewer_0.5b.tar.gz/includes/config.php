<?php

// Configuration
$version = '0.5 beta';
$table = 'mpls';
$database = 'mpls';
$user = '*user*';
$pass = '*pass*';

?>
