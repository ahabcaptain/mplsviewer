DROP TABLE IF EXISTS `mpls`;
CREATE TABLE `mpls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device` varchar(80) NOT NULL,
  `name` varchar(40) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `desc` varchar(120) NOT NULL,
  `export` varchar(40) NOT NULL,
  `import` varchar(40) NOT NULL,
  `exportmap` varchar(40) NOT NULL,
  `importmap` varchar(40) NOT NULL,
  `type` varchar(40) NOT NULL,
  `vrftype` varchar(10) NOT NULL,
  `family` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2755 DEFAULT CHARSET=latin1;
